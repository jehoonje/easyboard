export function showSpinner() {
  document.getElementById('loadingSpinner').style.display = 'flex';
}

export function hideSpinner() {
  document.getElementById('loadingSpinner').style.display = 'none';
}