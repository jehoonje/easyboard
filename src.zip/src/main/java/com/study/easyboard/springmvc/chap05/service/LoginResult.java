package com.study.easyboard.springmvc.chap05.service;

public enum LoginResult {

    SUCCESS, NO_ACC, NO_PW
}
